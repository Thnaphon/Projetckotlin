package com.example.LockerApp.viewmodel

class MainMenu {
}