package com.example.LockerApp.view

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.LockerApp.viewmodel.FaceDetectionViewModel

@Composable
fun PostRegisterCapture(
    navController: NavController,
    capturedFace: Bitmap,
    participantName: String,
    participantRole: String,
    participantPhone: String,
    viewModel: FaceDetectionViewModel
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Review Registration",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Display captured face
        Card(
            modifier = Modifier
                .size(300.dp)
                .padding(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Image(
                bitmap = capturedFace.asImageBitmap(),
                contentDescription = "Captured Face",
                modifier = Modifier.fillMaxSize()
            )
        }

        // Display participant information
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text("Name: $participantName", fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Role: $participantRole", fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Phone: $participantPhone", fontSize = 18.sp)
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = {
                    // Navigate back to face detection
                    navController.popBackStack()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Text("Capture Again")
            }

            Button(
                onClick = {
                    viewModel.registerFace(
                        participantName,
                        participantRole,
                        participantPhone,
                        capturedFace
                    )
                    // Navigate back to main screen or appropriate destination
                    navController.navigate("main_menu") {
                        popUpTo("face_detection") { inclusive = true }
                    }
                }
            ) {
                Text("Register Face")
            }
        }
    }
}