package com.example.LockerApp.view

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.example.LockerApp.utils.CameraManager
import com.example.LockerApp.viewmodel.FaceDetectionViewModel
import java.util.concurrent.Executors
import kotlinx.coroutines.launch

@Composable
fun FaceDetectionPage(
    navController: NavHostController,
    viewModel: FaceDetectionViewModel,
    participantName: String,
    participantPhone: String,
    participantRole: String
) {
    var showInstructions by remember { mutableStateOf(true) }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val cameraManager = remember { CameraManager(context) }
    val previewView = remember { androidx.camera.view.PreviewView(context) }

    val recognizedName by viewModel.recognizedName.observeAsState("Unknown")
    val capturedFace by viewModel.capturedFace.observeAsState()
    val registrationState by viewModel.registrationState.observeAsState()
    var shouldCaptureFace by remember { mutableStateOf(false) }

    val countdownState by viewModel.countdownState.observeAsState()
    val detectionState by viewModel.detectionState.observeAsState()
    val showCaptureOverlay by viewModel.showCaptureOverlay.observeAsState(false)

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            cameraManager.startCamera(
                lifecycleOwner = lifecycleOwner,
                previewView = previewView,
                cameraExecutor = cameraExecutor,
                onFaceDetected = { bitmap, rect ->
                    viewModel.updateDetectionState(1)

                    when (countdownState) {
                        is FaceDetectionViewModel.CountdownState.Idle -> {
                            if (!showCaptureOverlay) {
                                viewModel.startCountdown()
                            }
                        }
                        is FaceDetectionViewModel.CountdownState.Complete -> {
                            val faceBitmap = Bitmap.createBitmap(
                                bitmap,
                                rect.left.coerceAtLeast(0),
                                rect.top.coerceAtLeast(0),
                                rect.width().coerceAtMost(bitmap.width - rect.left),
                                rect.height().coerceAtMost(bitmap.height - rect.top)
                            )
                            val scaledBitmap = Bitmap.createScaledBitmap(faceBitmap, 250, 250, false)
                            viewModel.setCapturedFace(scaledBitmap)
                        }

                        else -> {
                            // Continue counting
                        }
                    }
                }
            )
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showInstructions) {
            AlertDialog(
                onDismissRequest = { showInstructions = false },
                title = { Text("Face Capture Instructions") },
                text = {
                    Column {
                        Text("1. จัดหน้าให้อยู่ตรงกลาง")
                        Text("2. เพิ่มระดับแสงให้เพียงพอ")
                        Text("3. ยืนนิ่งๆ")
                        Text("4. ต้องมีแค่ท่านในระหว่างลงทะเบียน")
                    }
                },
                confirmButton = {
                    Button(onClick = { showInstructions = false }) {
                        Text("Got it")
                    }
                }
            )
        }


        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Face Detection Page",
                fontSize = 24.sp,
                modifier = Modifier.align(Alignment.Center)
            )

            // Show detection status
            when (detectionState) {
                is FaceDetectionViewModel.DetectionState.NoFaceDetected -> {
                    Text(
                        text = "No face detected",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }

                is FaceDetectionViewModel.DetectionState.MultipleFacesDetected -> {
                    Text(
                        text = "Multiple faces detected",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }

                is FaceDetectionViewModel.DetectionState.SingleFaceDetected -> {
                    when (countdownState) {
                        is FaceDetectionViewModel.CountdownState.Counting -> {
                            val secondsLeft =
                                (countdownState as FaceDetectionViewModel.CountdownState.Counting).secondsLeft
                            Text(
                                text = "Keep still! Capturing in: $secondsLeft",
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.align(Alignment.CenterEnd)
                            )
                        }

                        else -> {
                            Text(
                                text = "Face detected",
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.align(Alignment.CenterEnd)
                            )
                        }
                    }
                }

                else -> {}
            }

            if (showCaptureOverlay && capturedFace != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            bitmap = capturedFace!!.asImageBitmap(),
                            contentDescription = "Captured Face",
                            modifier = Modifier
                                .size(250.dp)
                                .padding(16.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Button(
                                onClick = { viewModel.resetCapture() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary
                                )
                            ) {
                                Text("Capture Again")
                            }

                            Button(
                                onClick = {
                                    viewModel.resetCapture()
                                    navController.navigate(
                                        "post_register_capture?" +
                                                "name=${participantName}&" +
                                                "role=${participantRole}&" +
                                                "phone=${participantPhone}"
                                    )
                                }
                            ) {
                                Text("Use This Photo")
                            }
                        }
                    }
                }
            }

            AndroidView(
                factory = { previewView },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )

            capturedFace?.let { face ->
                Image(
                    bitmap = face.asImageBitmap(),
                    contentDescription = "Captured Face",
                    modifier = Modifier
                        .size(250.dp)
                        .padding(16.dp)
                )
            }

            Text(
                text = "Recognized: $recognizedName",
                fontSize = 20.sp,
                modifier = Modifier.padding(16.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = {
                    scope.launch {
                        capturedFace?.let { bitmap ->
                            viewModel.registerFace(
                                participantName,
                                participantRole,
                                participantPhone,
                                bitmap
                            )
                        } ?: run {
                            // Show error if no face is captured
                            Toast.makeText(
                                context,
                                "Please capture a face first",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }) {
                    Text("Register Face")
                }

                Button(onClick = {
                    // Mark that we want to capture the next detected face
                    shouldCaptureFace = true
                }) {
                    Text("Capture Face")
                }
            }

            // Show registration status
            registrationState?.let { state ->
                when (state) {
                    is FaceDetectionViewModel.RegistrationState.Success -> {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(16.dp)
                        )
//                        navController.navigate("main_menu")
                    }

                    is FaceDetectionViewModel.RegistrationState.Error -> {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}